<div class="well" style="margin: 10px 0 60px 0px;">
    <p align="center"><img src="../images/logo.png" height="75" /></p>
    <h4 align="center" style="margin: 15px 0 -10px 0;"><b>MENU DASHBOARD</br>STATUS KELULUSAN SISWA</b></h4>
    <hr>
    <div class="alert alert-dismissable alert-info" style="margin: 0 0 10px 0;">
        <h4 align="center"><b>MENU DASHBOARD</b></h4>
    </div>
    <div class="alert alert-dismissable alert-success" style="margin: 0 0 0 0;">
        <div class="alert alert-dismissable alert-danger" style="margin: 0 0 10px 0;">
            <h4 style="font-size: 14px;"> <a class="alert" href="index.php?page=profil" value=""><b>ATUR PROFIL</b></a></h4>
        </div>
        <div class="alert alert-dismissable alert-danger" style="margin: 0 0 10px 0;">
            <h4 style="font-size: 14px;"><a class="alert" href="datasiswa.php" value=""><b>DATA SISWA</b></a></h4>
        </div>
        <div class="alert alert-dismissable alert-danger" style="margin: 0 0 10px 0;">
            <h4 style="font-size: 14px;"><a class="alert" href="index.php?page=import" value=""><b>UPLOAD</b></a></h4>
        </div>
        <div class="alert alert-dismissable alert-danger" style="margin: 0 0 10px 0;">
            <h4 style="font-size: 14px;"><a class="alert" href="index.php?page=petugas" value=""><b>PENGGUNA</b></a></h4>
        </div>
    </div>
</div>